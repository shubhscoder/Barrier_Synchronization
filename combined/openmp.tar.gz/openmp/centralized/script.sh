rm *.o
rm mp2
rm mp1
