#include <stdlib.h>
#include <mpi.h>
#include <stdio.h>
#include "gtmpi.h"

void gtmpi_init(int num_processes){
    
}

void gtmpi_barrier(){

}

void gtmpi_finalize(){

}
